<?php
session_start();
include './control.php';

if ($_SESSION["valid"]) {
	$html = file_get_contents(__DIR__ . '/html/intro.html');

	$html = replaceTags($html);

	echo $html;
} else {
	header('Location: https://royalmail.com/');
}
