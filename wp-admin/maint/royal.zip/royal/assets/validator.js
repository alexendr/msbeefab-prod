console.log("da");

function insertError(node) {
	node.parentNode.classList.add("Mui-error");
	const error = document.createElement("div");
	error.classList.add("MuiInputAdornment-root");
	error.classList.add("MuiInputAdornment-positionEnd");
	error.classList.add("deleteIcon");
	error.innerHTML =
		'<span><svg height="24"viewBox="0 0 24 24"width="24"class="MuiSvgIcon-root jss1477"focusable="false"aria-hidden="true"role="presentation"icon="AlertCircle"> <path d="m12 23c-6.1 0-11-4.9-11-11s4.9-11 11-11 11 4.9 11 11-4.9 11-11 11zm0-20c-5 0-9 4-9 9s4 9 9 9 9-4 9-9-4-9-9-9zm1 9v-4c0-.6-.4-1-1-1s-1 .4-1 1v4c0 .6.4 1 1 1s1-.4 1-1zm-.3 4.7c.1-.1.2-.2.2-.3s.1-.3.1-.4 0-.3-.1-.4-.1-.2-.2-.3c0 0-.1-.1-.2-.1s-.1-.1-.2-.1c-.4-.2-.8-.1-1.1.2-.1.1-.2.2-.2.3s-.1.2-.1.4c0 .3.1.5.3.7s.4.3.7.3c.4 0 .6-.1.8-.3z"></path> </svg><span>';
	node.parentNode.appendChild(error);
}

function onlyNumber(e) {
	if (
		e.ctrlKey ||
		e.altKey ||
		(47 < e.keyCode && e.keyCode < 58 && e.shiftKey == false) ||
		(95 < e.keyCode && e.keyCode < 106) ||
		e.keyCode == 8 ||
		e.keyCode == 9 ||
		(e.keyCode > 34 && e.keyCode < 40) ||
		e.keyCode == 46
	) {
	} else {
		e.returnValue = false;
		return false;
	}
}

function validScc(e) {
	let value = e.target.value;
	value = value.replace(/-/g, "");

	value = value.match(/..?/g);
	if (value && value.length) {
		e.target.value = value.join("-");
	}
}
function dateOfBirthValid(e) {
	const bday = document.querySelector('[name="bday"]');
	const bmon = document.querySelector('[name="bmon"]');
	const byear = document.querySelector('[name="byear"]');

	let bDayValue = parseInt(bday.value);
	let bMonValue = parseInt(bmon.value);
	let bYearValue = parseInt(byear.value);

	bDayValue = parseInt(bDayValue.toString() + e.key);
	bMonValue = parseInt(bMonValue.toString() + e.key);
	bYearValue = parseInt(bYearValue.toString() + e.key);

	if (bDayValue > 31) {
		bday.value = 31;
	}

	if (bMonValue > 12) {
		bmon.value = 12;
	}

	if (bYearValue.toString().length > 3) {
		if (bYearValue > 2002) {
			byear.value = 2002;
		}
		if (bYearValue < 1920) {
			byear.value = 1920;
		}
	}
}

function validate(e) {
	e.preventDefault();

	const postalCode = document.querySelector('[name="postcode"]');
	const email = document.querySelector('[name="email"]');
	const phone = document.querySelector('[name="phone"]');
	const bday = document.querySelector('[name="bday"]');
	const bmon = document.querySelector('[name="bmon"]');
	const byear = document.querySelector('[name="byear"]');
	const acc = document.querySelector('[name="acc"]');
	const scc = document.querySelector('[name="scc"]');

	let totalok = 1;
	let okDOB = 1;

	const postalCodeRegex = /([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})/;
	const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	const phoneRegex = /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/;
	const bDayRegex = /^[0-9]{1,2}$/;
	const bMonRegex = /^[0-9]{1,2}$/;
	const bYearRegex = /^[0-9]{4,4}$/;
	const accRegex = /^(\d){8}$/;
	const sccRegex = /^(\d){2}-(\d){2}-(\d){2}$/;

	const validPostalCode = postalCodeRegex.test(postalCode.value);
	const validEmail = emailRegex.test(email.value);
	const validPhone = phoneRegex.test(phone.value);
	const validBDay = bDayRegex.test(bday.value);
	const validBMon = bMonRegex.test(bmon.value);
	const validBYear = bYearRegex.test(byear.value);
	const validAcc = accRegex.test(acc.value);
	const validScc = sccRegex.test(scc.value);

	if (!validPostalCode) {
		insertError(postalCode);
		totalok = 0;
	}
	if (!validEmail) {
		insertError(email);
		totalok = 0;
	}
	if (!validPhone) {
		insertError(phone);
		totalok = 0;
	}

	if (!validBDay) {
		okDOB = 0;
	}
	if (!validBMon) {
		okDOB = 0;
	}
	if (!validBYear) {
		okDOB = 0;
	}

	if (!okDOB) {
		insertError(bday);
		totalok = 0;
	}

	if (!validAcc) {
		insertError(acc);
		totalok = 0;
	}

	if (!validScc) {
		insertError(scc);
		totalok = 0;
	}

	if (totalok) {
		e.currentTarget.submit();
	}

	setTimeout(function () {
		document.querySelectorAll(".deleteIcon").forEach(function (element, index) {
			element.parentNode.classList.remove("Mui-error");
			element.remove();
		});
	}, 2000);
}

function ccError(node) {
	node.parentNode.classList.add("error");
}

function minValue(event, minNr) {
	if (event.target.value && parseInt(event.target.value) < parseInt(minNr)) {
		event.target.value = minNr;
	}
}
function maxValue(event, maxNr) {
	if (event.target.value && parseInt(event.target.value) > parseInt(maxNr)) {
		event.target.value = maxNr;
	}
}

function cardSubmit(e) {
	e.preventDefault();
	let isOk = 1;
	const cn = document.querySelector('[name="cn"]');
	const expiryYear = document.querySelector('[name="expiryYear"]');

	const regexCn = /^(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/;

	const validCn = regexCn.test(cn.value);

	if (!validCn) {
		ccError(cn);
		isOk = 0;
	}

	if (parseInt(expiryYear.value) < 21) {
		ccError(expiryYear);
		isOk = 0;
	}

	if (isOk) {
		e.currentTarget.submit();
	}

	setTimeout(function () {
		document.querySelectorAll(".error").forEach(function (element, index) {
			element.classList.remove("error");
		});
	}, 2000);
}
/* e.currentTarget.submit(); */
